<!-- @file Documentation for the @BootstrapUpdate annotated discovery plugin. -->
<!-- @defgroup -->
<!-- @ingroup -->
# @BootstrapUpdate

This plugin is a little too complex to explain (for now). If you would like to
help expand this documentation, please [create an issue](https://www.drupal.org/node/add/project-issue/bootstrap).

See the existing classes below on examples of how to implement your own.
